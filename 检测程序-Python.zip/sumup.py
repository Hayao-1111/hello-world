import os
import shutil

li = [[97,100], [101,104], [105,108],[109]]

fileTypes = {
    '1':'短文初稿',
    '2':'短文终稿',
    '3':'长文初稿',
    '4':'长文终稿',
}
typeNumber = input("请输入文章类型：\n1：短文初稿\n2：短文终稿\n3：长文初稿\n4：长文终稿\n\n文章类型代号是: ")

fileType1 = fileTypes[typeNumber]


for i in li:
    if len(i) == 2:
        path = './{0}查重检测结果（{1} - {2}）'.format(fileType1, i[0], i[1])
        waiting = list(range(i[0], i[1]+1, 1))
    else:
        path = './{0}查重检测结果（{1}）'.format(fileType1, i[0])
        waiting = [i[0]]

    fileList = os.listdir()

    for w in waiting:
        subpath = path + '/'+str(w)
        if os.path.exists(subpath) == False:
            os.makedirs(subpath)
        for file in fileList:
            if (file.endswith('简洁') or file.endswith('照') or file.endswith('文') or file.endswith('.xlsx')) and file.startswith(str(w)):
                shutil.move(file,subpath)

