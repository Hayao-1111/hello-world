import os
import shutil

def m_copyRename(start_number, end_number):
    '''
    本函数的作用：将检测结果（表格*1 + RAR文件*3）从子文件夹移动到当前目录，并规范命名
    '''
    li = list(range(start_number,end_number+1,1))
    m_dict = {
        '1':'检测报告_全文对照',
        '2':'检测报告_简洁',
        '3':'检测报告_全文标明引文',
    }

    for i in li:
        path = './'+str(i)
        for j in range(1,4,1):
            path2 = path + '/'+str(j)+'.rar'
            if os.path.exists(path2):
                destPath = './'+str(i)+'_'+m_dict[str(j)]+'.rar'
                shutil.copy(path2, destPath)

        path3 = './'+str(i)+'/'+str(0)+'.xlsx'
        if os.path.exists(path3):
            destPath3 = './'+str(i)+'_检测报告单.xlsx'
            shutil.copy(path3, destPath3)


if __name__ == "__main__":
    
    # 将已有的ZIP文件移动到固定的文件夹
    ZIPfolder = './ZIP_Files_studentsEaasys'
    if os.path.exists(ZIPfolder) == False:
        os.mkdir('./ZIP_Files_studentsEaasys')

    fileList = os.listdir()
    for file in fileList:
        if file.endswith('.zip'):
            shutil.move(file,ZIPfolder)

    # 将制定范围的检测结果文件移动并重命名
    print("请输入待检测的课序号（起点与终点）")
    first = int(input("Plaese input the start number: "))
    second = int(input("Please input the end number: "))
    m_copyRename(first, second)
