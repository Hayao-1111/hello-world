"""
本程序的作用：生成对应课序号的文件夹，在当前目录；
1.0版本只支持连续课序号的情况，课序号不连续的情况将在2.0版本中实现
"""
import os

def foldersMaker(start, end):
    '''
    课序号连续时，生成一系列文件夹
    '''
    courseNumbers = range(start, end+1, 1)
    for courseNumber in courseNumbers:
        path = './' + str(courseNumber)
        if os.path.exists(path) == False:
            os.mkdir(path)
            print("Folder " + path + "Made Successfully!")

if __name__ == "__main__":
    strat_number = int(input("Please input the start course number(Must be an integer): "))
    end_number = int(input("Please input the end course number(Must be an integer): "))
    foldersMaker(strat_number,end_number)
    useless = input("All folders made successfully! Please enter any key to exit. ")

